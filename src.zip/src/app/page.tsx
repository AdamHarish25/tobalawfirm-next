// src/app/page.tsx (FINAL)
'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from "next/navigation";
import { Database } from "@/Database/WholeData";
import { FaChevronRight, FaStar, FaCompass, FaWallet, FaHandshake, FaClock, FaShieldAlt } from "react-icons/fa";
import Tabs from "@/components/Tabs/Tabs";
import Accordion from "@/components/Accordion/Accordion";
import Link from "next/link";
import { collection, getDocs, query, where, orderBy, limit } from "firebase/firestore";
import { db } from "@/firebase";
import Navbar from '@/components/Navbar';

interface Service {
    id: string;
    title: string;
    subtitle?: string;
}

const Datas = Database.HomeData;

const AccordionChild = ({ children, header, icon }: { children: React.ReactNode, header: string, icon: React.ReactNode }) => (
    <>{children}</>
);

// --- KOMPONEN DIPERBAIKI ---
const HomePage_1 = () => {
    const router = useRouter();
    const Data = Datas.page_1;
    return (
        // DIV LUAR: Bertugas untuk background full-width
        <div className="w-full h-screen bg-cover bg-center bg-black/50 bg-blend-darken relative bg-background2">
            {/* DIV DALAM: Bertugas untuk membatasi dan memusatkan konten */}
            <div className="container mx-auto h-full grid grid-cols-1 lg:grid-cols-2 place-items-center lg:px-20 py-10 font-Playfair_Display">
                <div className="w-full h-full absolute inset-0 bg-black/50" />
                <div></div>
                <div className="w-full space-y-8 text-white z-10">
                    <h1 className="text-4xl md:text-5xl font-bold">{Data.title}</h1>
                    <p className="text-white/80">{Data.subtitle}</p>
                    <div className="flex items-center gap-2 font-Roboto">
                        {Data.button.map((data, index) => (
                            <button key={index} onClick={() => router.push(data.link)} className={index > 0 ? "flex items-center text-xs gap-5 bg-transparent rounded-sm border border-white p-3 hover:border-0 hover:bg-white hover:text-black" : "flex items-center text-xs gap-5 bg-yellow-500 text-black rounded-sm p-3"}>
                                <p>{data.title}</p> <FaChevronRight />
                            </button>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
};

// --- KOMPONEN DIPERBAIKI (Struktur Flexbox untuk alignment yang lebih baik) ---
const HomePage_2 = () => {
    const router = useRouter();
    const Data = Datas.page_2;
    return (
        <div className="w-full container mx-auto p-10">
            <div className="flex flex-col md:flex-row justify-around items-center gap-10">
                <div className="space-y-10 flex flex-col items-center md:items-start text-justify text-white order-2 md:order-1 max-w-3xl">
                    <h1 className="text-3xl md:text-4xl font-Playfair_Display font-bold text-center md:text-left">{Data.title}</h1>
                    <p className="text-white/60 whitespace-pre-line">{Data.subtitle}</p>
                    <button onClick={() => router.push(Data.button.link)} className="flex items-center text-xs gap-5 bg-yellow-500 text-black rounded-sm p-3">
                        <p>{Data.button.title}</p> <FaChevronRight />
                    </button>
                </div>
                <img src={Data.img} alt={Data.title} className="grayscale h-auto md:h-[500px] rounded-lg order-1 md:order-2" />
            </div>
        </div>
    );
};

// --- KOMPONEN DIPERBAIKI ---
const HomePage_3 = () => {
    const Data = Datas.page_3;
    return (
        <div className="w-full bg-dark-gray my-20">
            <div className="container mx-auto p-10 space-y-16 font-Roboto text-white">
                <div className="w-full text-center">
                    <h1 className="text-3xl md:text-4xl font-Playfair_Display font-medium px-5 md:px-0">{Data.title}</h1>
                </div>
                <div className="w-full grid grid-cols-1 md:grid-cols-2 gap-10 place-items-start">
                    {Data.cards.map((data, index) => (
                        <div key={index} className="p-5 flex flex-col items-center text-center gap-5 max-w-xl mx-auto">
                            <p className="text-5xl text-yellow-500">{data.icon}</p>
                            <h1 className="text-xl md:text-3xl font-medium font-Playfair_Display">{data.title}</h1>
                            <p className="text-white/60">{data.subtitle}</p>
                        </div>
                    ))}
                </div>
                <div className="w-full text-start">
                    <p className="text-white/60">*{Data.subtitle}</p>
                </div>
            </div>
        </div>
    );
};

const HomePage_4 = () => {
    const router = useRouter();
    const Data = Datas.page_4;
    const [services, setServices] = useState<Service[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchServices = async () => {
            setLoading(true);
            try {
                const servicesRef = collection(db, "services");
                const q = query(servicesRef, where("isPublished", "==", true), orderBy("title", "asc"), limit(6));
                const querySnapshot = await getDocs(q);
                const servicesData = querySnapshot.docs.map((doc) => ({
                    id: doc.id,
                    title: doc.data().title,
                    subtitle: doc.data().subtitle,
                }));
                setServices(servicesData);
            } catch (error) {
                console.error("Error fetching services for homepage:", error);
            } finally {
                setLoading(false);
            }
        };
        fetchServices();
    }, []);

    return (
        <div className="w-full space-y-8 text-white p-10 mx-auto container">
            <div className="w-full flex flex-col gap-10 items-start justify-center lg:flex-row lg:items-center lg:justify-between">
                <h1 className="text-3xl md:text-4xl font-medium font-Playfair_Display md:pl-5">{Data.title}</h1>
                <button onClick={() => router.push(Data.button.link)} className="px-6 py-4 transition-transform duration-400 rounded-lg border border-white hover:text-black hover:bg-white flex items-center gap-4 text-xs">
                    <p>{Data.button.title}</p> <FaChevronRight />
                </button>
            </div>
            <div className="p-5 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 place-items-start gap-20 w-full">
                {loading ? (
                    <p className="col-span-full text-center text-gray-400">Loading services...</p>
                ) : (
                    services.map((data, index) => (
                        <div key={data.id} className="space-y-5 w-full h-full">
                            <div className="p-5 w-fit grid place-items-center font-Playfair_Display font-bold rounded-tl-lg rounded-br-lg bg-yellow-500 text-black text-2xl relative"><h1 className="absolute">{index + 1}</h1></div>
                            <h4 className="text-xl font-semibold font-Playfair_Display">{data.title}</h4>
                            {data.subtitle && <p className="text-lg text-white/60">{data.subtitle}</p>}
                        </div>
                    ))
                )}
            </div>
        </div>
    );
};

const HomePage_5 = () => {
    const Data = Datas.page_5;
    return (
        <div className="w-full p-10 space-y-10 bg-dark-gray">
            <div className="w-full text-center">
                <h1 className="text-2xl md:text-4xl font-Playfair_Display text-white font-semibold">{Data.title}</h1>
            </div>
            <Tabs tabs={Data.tabs} />
        </div>
    );
};

const HomePage_6 = () => {
    const Data = Datas.page_6;
    return (
        <div className="w-full space-y-10 p-10 text-white mx-auto container">
            <Accordion>
                {Data.map((data, index) => (
                    <AccordionChild key={index} header={data.title} icon={data.icon}>
                        <div className="w-full grid grid-cols-1 gap-10 md:grid-cols-2 place-items-center p-10">
                            <h1 className="text-5xl font-Playfair_Display font-semibold">{data.title}</h1>
                            <ul className="w-full space-y-3 text-white/60 list-decimal text-lg pl-5">
                                {data.content.map((item, idx) => <li key={idx}>{item.title}</li>)}
                            </ul>
                        </div>
                    </AccordionChild>
                ))}
            </Accordion>
        </div>
    );
};

const HomePage_7 = () => (
    <div className="w-full p-10 lg:p-20 text-center bg-dark-gray text-white space-y-8">
        <h1 className="text-3xl md:text-4xl font-bold font-Playfair_Display">{Datas.page_7.title}</h1>
        <p className="max-w-2xl mx-auto text-gray-300">
            Siap untuk mendiskusikan kebutuhan hukum Anda? Tim kami yang berdedikasi siap membantu. Klik di bawah untuk menemukan cara terbaik menghubungi kami.
        </p>
        <Link href="/contact" className="inline-block bg-yellow-500 text-black font-bold text-lg py-4 px-8 rounded hover:bg-yellow-400 transition-colors duration-300">
            Hubungi Kami Sekarang
        </Link>
    </div>
);

export default function Home() {
    return (
        <div className='w-full'>
            <Navbar />

            <HomePage_1 />
            <HomePage_2 />
            <HomePage_3 />
            <HomePage_4 />
            <HomePage_5 />
            <HomePage_6 />
            <HomePage_7 />
        </div>
    );
}