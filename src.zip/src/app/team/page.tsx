// src/app/team/page.tsx (FINAL & LENGKAP)
'use client';

import { FaChevronRight } from "react-icons/fa";
import { Database } from "@/Database/WholeData";
import { useRouter } from "next/navigation";
import Link from "next/link";
import React from 'react';
import Head from 'next/head';
import Image from 'next/image';
import Navbar from "@/components/Navbar";

const Datas = Database.TeamData;

const TeamPage_1 = () => (
    <div className="w-full p-20 text-center bg-dark-gray text-white">
        <div className="text-3xl font-Playfair_Display font-medium">{Datas.page_1.title}</div>
    </div>
);

const TeamPage_2 = () => {
    const router = useRouter();
    const Data = Datas.page_2;
    return (
        <div className="w-full h-full grid grid-cols-1 gap-10 md:grid-cols-2 place-items-center px-10 py-44">
            <div className="space-y-10 grid place-items-center text-justify text-white order-2 md:order-1">
                <h1 className="text-3xl md:text-4xl font-Playfair_Display font-bold">{Data.title}</h1>
                <p className="text-white/60 whitespace-pre-line">{Data.subtitle}</p>
                <button onClick={() => router.push(Data.button.link)} className="flex items-center text-xs gap-5 bg-yellow-500 text-black rounded-sm p-3">
                    <p>{Data.button.title}</p> <FaChevronRight />
                </button>
            </div>
            <img src={Data.img} alt="Tim Toba Lawfirm" className="grayscale h-auto md:h-[500px] rounded-lg order-1 md:order-2" />
        </div>
    );
};

const TeamPage_3 = () => (
    <div className="w-full p-10 grid grid-cols-1 md:grid-cols-2 gap-8 place-items-center bg-dark-gray">
        {Datas.page_3.map((data, idx) => (
            <div key={idx} className="w-full space-y-10 grid place-items-center gap-5 p-5">
                <Image className="w-60 h-60 rounded-full object-cover object-top" alt={data.name} src={data.img} width={240} height={240} />
                <div className="space-y-4 text-center text-white">
                    <h1 className="text-2xl md:text-3xl font-semibold font-Playfair_Display">{data.name}</h1>
                    <h4 className="text-lg font-Poppins font-medium text-yellow-500">{data.role}</h4>
                    <ul className="flex items-center justify-center gap-5 list-none">
                        {data.socials.map((social, idx2) => (
                            <li key={idx2}>
                                <a href={social.link} target="_blank" rel="noopener noreferrer" className="cursor-pointer text-white/70 hover:text-white">
                                    {social.icon}
                                </a>
                            </li>
                        ))}
                    </ul>
                </div>
            </div>
        ))}
    </div>
);

export default function TeamPage() {
    return (
        <div className="w-full font-Roboto text-white bg-dark-white">
            <Head>
                <title>Tim Kami - Toba Lawfirm</title>
                <meta name="description" content="Lawfirm yang baik memiliki tim yang solid, berpengalaman, dan profesional. Pelajari lebih lanjut tentang tim kami di Toba Lawfirm." />
            </Head>

            <Navbar />

            <TeamPage_2 />
            <TeamPage_1 />
            <TeamPage_3 />
        </div>
    );
}