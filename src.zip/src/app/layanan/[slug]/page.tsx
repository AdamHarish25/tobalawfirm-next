// src/app/layanan/[slug]/page.tsx (FINAL & LENGKAP)

import { collection, query, where, getDocs, limit } from 'firebase/firestore';
import { db } from '@/firebase';
import Link from 'next/link';
import type { Metadata } from 'next';
import Image from 'next/image';

interface Service {
    id: string;
    title: string;
    content: string;
    slug: string;
    subtitle?: string;
    featuredImageUrl?: string;
}

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const service = await getService(params.slug);
  if (!service) {
    return { title: 'Layanan Tidak Ditemukan' };
  }
  return {
    title: service.title,
    description: service.subtitle || service.content.replace(/<[^>]+>/g, '').substring(0, 155),
  };
}

async function getService(slug: string): Promise<Service | null> {
    const servicesRef = collection(db, 'services');
    const q = query(servicesRef, where('slug', '==', slug), where('isPublished', '==', true), limit(1));
    const querySnapshot = await getDocs(q);
    if (querySnapshot.empty) return null;
    
    const docData = querySnapshot.docs[0].data();
    return {
        id: querySnapshot.docs[0].id,
        title: docData.title,
        content: docData.content,
        slug: docData.slug,
        subtitle: docData.subtitle,
        featuredImageUrl: docData.featuredImageUrl
    } as Service;
}

export default async function ServiceDetailPage({ params }: { params: { slug: string } }) {
    const service = await getService(params.slug);
    const waMe = "https://wa.me/628111072535"; 

    if (!service) {
        return (
            <div className="min-h-screen flex flex-col items-center justify-center text-white text-center">
                <h1 className="text-3xl font-Playfair_Display text-red-500">Layanan Tidak Ditemukan</h1>
                <Link href="/service" className="mt-4 text-yellow-500 hover:underline">← Kembali ke daftar layanan</Link>
            </div>
        );
    }

    return (
        <main className="bg-dark-white text-gray-300 font-Roboto">
            <header
                className="h-[60vh] flex items-center justify-center text-center text-white bg-cover bg-center bg-black/50 bg-blend-darken"
                style={{ backgroundImage: `url(${service.featuredImageUrl || '/images/backgroundService.jpg'})` }}
            >
                <div className="max-w-4xl px-4">
                    <h1 className="text-4xl lg:text-6xl font-bold font-Playfair_Display leading-tight">
                        {service.title}
                    </h1>
                </div>
            </header>

            <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24">
                <article
                    className="prose prose-lg lg:prose-xl prose-invert max-w-none prose-headings:font-Playfair_Display"
                    dangerouslySetInnerHTML={{ __html: service.content }}
                />
                <div className="text-center my-16">
                    <Link
                        href="/contact"
                        className="inline-block bg-yellow-500 text-black font-bold text-lg py-4 px-8 rounded hover:bg-yellow-400 transition-colors"
                    >
                        Mulai Konsultasi dengan kami Gratis!
                    </Link>
                </div>
                <div className="mt-8 text-center space-y-5 grid grid-cols-1 place-items-center">
                    <h2 className="text-2xl font-bold">Mungkin Anda juga tertarik</h2>
                    <a href={waMe} target="_blank" rel="noopener noreferrer">
                        <Image
                            src="/images/Poster2.png" // Path di public folder
                            alt="Poster Layanan"
                            width={500}
                            height={700}
                            className="rounded-3xl border-2 border-yellow-500"
                        />
                    </a>
                </div>
            </div>
        </main>
    );
}