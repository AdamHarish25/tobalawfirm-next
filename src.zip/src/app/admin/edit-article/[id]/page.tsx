// src/app/admin/edit-article/[id]/page.tsx (FINAL)
import EditArticleForm from "@/components/admin/forms/EditArticleForm";

export default function Page() {
    return <EditArticleForm />;
}