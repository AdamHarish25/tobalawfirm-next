// src/app/admin/create-article/page.tsx (FINAL)
import CreateArticleForm from "@/components/admin/forms/CreateArticleForm";

export default function Page() {
    return <CreateArticleForm />;
}