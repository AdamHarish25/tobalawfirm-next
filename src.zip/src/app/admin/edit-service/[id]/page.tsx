// src/app/admin/edit-service/[id]/page.tsx (FINAL)
import EditServiceForm from "@/components/admin/forms/EditServiceForm";

export default function Page() {
    return <EditServiceForm />;
}