// src/app/admin/create-service/page.tsx (FINAL)
import CreateServiceForm from "@/components/admin/forms/CreateServiceForm";

export default function Page() {
    return <CreateServiceForm />;
}