// src/app/about/page.tsx (FINAL & LENGKAP)
'use client';

import { useRouter } from "next/navigation";
import { Database } from "@/Database/WholeData";
import { FaChevronRight, FaStar, FaCompass } from "react-icons/fa";
import Accordion from "@/components/Accordion/Accordion";
import React from 'react';
import Head from 'next/head';
import Navbar from "@/components/Navbar";

const Datas = Database.AboutData;

const AccordionChild = ({ children, header, icon }: { children: React.ReactNode, header: string, icon: React.ReactNode }) => {
  return <>{children}</>;
};

const AboutPage_1 = () => (
  <div className="w-full pt-32 pb-16 bg-dark-gray text-center text-white">
    <h1 className="text-3xl font-medium font-Playfair_Display">{Datas.page_1.title}</h1>
  </div>
);

const AboutPage_2 = () => {
  const router = useRouter();
  const Data = Datas.page_2;
  return (
    <div className="w-full h-full grid grid-cols-1 gap-10 md:grid-cols-2 place-items-center p-10">
      <div className="space-y-10 grid place-items-center text-justify text-white order-2 md:order-1">
        <h1 className="text-3xl md:text-4xl font-Playfair_Display font-bold">{Data.title}</h1>
        <p className="text-white/60 whitespace-pre-line">{Data.subtitle}</p>
        <button onClick={() => router.push(Data.button.link)} className="flex items-center text-xs gap-5 bg-yellow-500 text-black rounded-sm p-3">
          <p>{Data.button.title}</p> <FaChevronRight />
        </button>
      </div>
      <img src={Data.img} alt="Tentang Toba Lawfirm" className="grayscale h-auto md:h-[500px] rounded-lg order-1 md:order-2" />
    </div>
  );
};

const AboutPage_3 = () => (
  <div className="w-full space-y-10 p-10 text-white">
    <Accordion>
      {Datas.page_3.map((data, index) => (
        <AccordionChild key={index} header={data.title} icon={data.icon}>
          <div className="w-full grid grid-cols-1 gap-10 md:grid-cols-2 place-items-center p-10">
            <h1 className="text-4xl font-Playfair_Display font-medium">{data.title}</h1>
            <ul className="w-full space-y-3 text-white/60 list-decimal pl-5">
              {data.content.map((item, idx) => <li key={idx}>{item.title}</li>)}
            </ul>
          </div>
        </AccordionChild>
      ))}
    </Accordion>
  </div>
);

export default function AboutPage() {
  return (
    <div className="w-full font-Roboto text-white bg-dark-white">
      <Head>
        <title>Tentang Kami - Toba Lawfirm</title>
        <meta name="description" content="Pelajari tentang Visi, Misi dan Sejarah TobaLawfirm." />
      </Head>
      <Navbar />

      <AboutPage_1 />
      <AboutPage_2 />
      <AboutPage_3 />
    </div>
  );
}